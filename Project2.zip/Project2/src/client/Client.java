import java.io.*;
import java.net.Socket;
/**
 * THIs is a distributed drawing board system
 * The client class is defined to start a client to build connection
 * requests and establish a connection with server.
 *
 *@author Guangxing Si
 *@version 1.0
 */
public class Client {
    private String clientId;
    private ClientGUI clientGUI;

    public Client(String clientId){
        this.clientId = clientId;
    }
    public static void main(String[] args) throws IOException {
        String clientName = "";
        try{
            clientName = args[2];

        }catch (NullPointerException e){
            System.out.println("Please provide a user name");
        }catch (ArrayIndexOutOfBoundsException error){
            System.out.println("Please enter correct number of arguments");
            System.exit(0);
        }
        Client client = new Client(clientName);
        client.authentication(client.clientId);
        client.start(args[0], args[1]);
    }

    public Socket createSocket(String ip, int port) {
        Socket socket = null;
        try{
            socket = new Socket(ip, port);
            System.out.println("Connection Established");
        }catch(IOException e)
        {
            System.out.println("Connection failed. Please retry and check your IP and Port number");
            System.exit(0);
        }
        return socket;
    }

    public void authentication(String id){
        System.out.println("Welcome " +  id + " we are logging you in...");
    }

    public void start(String localhost, String portString) {
        DataOutputStream out;
        DataInputStream in;
        int port = Integer.parseInt(portString);
        Socket socket = createSocket(localhost, port);

        try{
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            ClientGUI clientGUI  = new ClientGUI(in, out, clientId);
            out.writeUTF(clientId);
            clientGUI.form();
            clientGUI.listener();
        }catch(IOException e){
            System.out.println("I/O exception from socket, please restart the client");
            System.exit(0);
        }catch (NullPointerException e){
            System.out.println("Connection failed. Socket not created properly");
            System.exit(0);
        }

    }
}

