import com.google.gson.Gson;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
/**
 *@author Guangxing Si
 *@version 1.0
 */
public class Canvas extends JComponent {

    private BasicStroke basicStroke = new BasicStroke(4);
    private Color basicColor = Color.black;
    private final Color BACKGROUND_COLOR = new Color(242,238,203);

    private SHAPE shape;
    private Painter painter;
    private ArrayList<Painter> painters = new ArrayList<>();

    private int startX;
    private int startY;
    private int finishX;
    private int finishY;

    private Boolean clearPrevious = true;
    private Boolean isManager = false;
    private Boolean isClear = false;
    private DataOutputStream out;
    private HashMap<String, DataOutputStream> outs = new HashMap<>();
    private Gson gson = new Gson();

    public Canvas(){
        setDoubleBuffered(false);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                startX = e.getX();
                startY = e.getY();
                finishX = startX;
                finishY = startY;

            }
        });

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                super.mouseDragged(e);
                sendStatus("editing");
                finishX = e.getX();
                finishY = e.getY();
                repaint();

            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                sendStatus("stop");
                painter = new Painter(shape, basicColor);
                painter.setStartX(startX);
                painter.setStartY(startY);
                painter.setFinishY(finishY);
                painter.setFinishX(finishX);

                if(painter != null){
                    Gson gson = new Gson();
                    String sendJSON = gson.toJson(painter);
                    sendShape(sendJSON);
                    addShape(painter);
                    repaint();
                }
            }
        });
        this.setPreferredSize(new Dimension(400, 400));
    }

    public void paintComponent(Graphics g){
        Graphics2D g2D = (Graphics2D) g;
        g2D.setColor(BACKGROUND_COLOR);
        g2D.fillRect(0,0,getSize().width, getSize().height);
        g2D.setColor(basicColor);
        g2D.setStroke(basicStroke);

        if (isClear || (shape == null && painters.isEmpty())){
            isClear = false;
            shape = null;
            return;
        }

        if(shape != null){
            switch(shape) {
                case RECTANGLE:
                    rectDraw(g2D);
                    break;
                case CIRCLE:
                    circleDraw(g2D);
                    break;
                case OVAL:
                    ovalDraw(g2D);
                    break;
                case LINE:
                    lineDraw(g2D);
                    break;
                case TEXT:
                    textDraw(g2D);
                    break;
                default:
                    break;
            }
        }
        clearPrevious = true;
        for (Painter cr : painters){
            int[] coordination = cr.getCoordination();
            switch (cr.getShape()){
                case RECTANGLE:
                    cr.rectDraw(g2D);
                    break;
                case LINE:
                    cr.lineDraw(g2D);
                    break;
                case CIRCLE:
                    cr.circleDraw(g2D);
                    break;
                case OVAL:
                    cr.ovalDraw(g2D);
                    break;
                case TEXT:
                    cr.textDraw(g2D);
                    break;
                default:
                    break;
            }
        }
    }

    public void addReceivedShape(Painter painter){
        addShape(painter);
        repaint();
    }

    public void setIsManager(Boolean isManager){
        this.isManager = isManager;
    }

    public void setOuts(HashMap<String, DataOutputStream> outs){
        this.outs = outs;
    }

    public void setOut(DataOutputStream out){
        this.out = out;
    }

    public void managerSendStatus(String status){
        String action = "EDITING";
        for(String key : outs.keySet()){
            try{
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF("0");
                outs.get(key).writeUTF(status);
            }
            catch(IOException e){
                System.out.println("Error in manager send status");
            }
        }
    }

    public void managerSendShape(String msg){
        String action = "DRAW";
        for(String key : outs.keySet()){
            try{
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(msg);
            }
            catch(IOException e){
                System.out.println("Send msg to data exchange");
            }
        }
    }

    public void managerSendClear(){
        String action = "CLEAR";
        int i = 0;
        for(String key : outs.keySet()){
            try{
                outs.get(key).writeUTF(action);
            }
            catch(IOException e){
                System.out.println("Send msg in data exchange");
            }
        }
    }
    public void sendStatus(String status){
        String action = "EDITING";
        try{
            if(isManager){
                managerSendStatus(status);
            }else{
                out.writeUTF(action);
                out.writeUTF(status);
            }
        }catch(IOException e){
            System.out.println("Writing error in send status");
        }
    }

    public void sendShape(String shapeJSONString) {
        String action = "DRAW";
        try{
            if(isManager){
                managerSendShape(shapeJSONString);
            }else{
                out.writeUTF(action);
                out.writeUTF(shapeJSONString);
            }
        }catch(IOException e){
            System.out.println("Writing error in sendShape");
        }

    }

    public void sendClear() {
        String action = "CLEAR";
        try{
            if(isManager){
                managerSendClear();
            }else{
                out.writeUTF(action);}
        }catch(IOException e){
            System.out.println("Writing error in sendClear");
        }
    }

    public void clear(){
        isClear = true;
        painters.clear();
        clearPrevious = false;
        this.removeAll();
        repaint();
    }

    public void addShape(Painter painter){
        if(painter.getShape() != null){
            painters.add(painter);
        }
    }

    public ArrayList<Painter> getShapes() {
        return painters;
    }

    public void textDraw(Graphics2D g){
        JTextField jtf = new JTextField();
        jtf.setOpaque(false);
        jtf.setBorder(null);
        jtf.setEditable(true);
        jtf.setBounds(startX, startY, 500, 30);
        jtf.setCaretPosition(jtf.getText().length());
        jtf.setForeground(basicColor);
        this.add(jtf);
        Painter textShape = new Painter(SHAPE.TEXT, basicColor);
        textShape.setStartX(startX);
        textShape.setStartY(startY + 20);
        jtf.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
            }
            @Override
            public void focusLost(FocusEvent e) {
                textShape.setText(jtf.getText());
                Gson gson = new Gson();
                String sendJSON = gson.toJson(textShape);
                sendShape(sendJSON);
                addShape(textShape);
            }
        });
    };


    public void lineDraw(Graphics2D g){
        g.drawLine(startX, startY, finishX, finishY);
    }

    public void rectDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);
        g.setColor(basicColor);
        g.drawRect(currentX, currentY, width, height);
    }

    public void circleDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);
        int diameter = (int)Math.sqrt(Math.pow(width,2) + Math.pow(height,2));
        g.setColor(basicColor);
        g.drawOval(currentX, currentY, diameter, diameter);
    }

    public void ovalDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);
        g.setColor(basicColor);
        g.drawOval(currentX, currentY, width, height);
    }

    public void setBasicColor(Color basicColor) {
        this.basicColor = basicColor;
    }

    public void setShape(SHAPE shape){
        this.shape = shape;
    }
}
