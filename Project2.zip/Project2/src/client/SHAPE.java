/**
 *@author Guangxing Si
 *@version 1.0
 */
public enum SHAPE{
    RECTANGLE,
    CIRCLE,
    OVAL,
    LINE,
    TEXT,
    PEN
}