import java.awt.*;
/**
 *@author Guangxing Si
 *@version 1.0
 */
public class Painter {
    private int startX;
    private int startY;
    private int finishX;
    private int finishY;

    private SHAPE shape;
    private Color color;
    private String text = "";

    public Painter(SHAPE shape, Color color) {
        this.shape = shape;
        this.color = color;
    }

    public void textDraw (Graphics2D g){
        g.setColor(color);
        g.drawString(text, startX, startY);
    }

    public void rectDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);
        g.setColor(color);
        g.drawRect(currentX, currentY, width, height);
    }

    public void circleDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);

        int diameter = (int)Math.sqrt(Math.pow(width,2) + Math.pow(height,2));
        g.setColor(color);
        g.drawOval(currentX, currentY, diameter, diameter);
    }

    public void lineDraw(Graphics2D g){
        g.setColor(color);
        g.drawLine(startX, startY, finishX, finishY);
    }

    public void setText(String text){
        this.text = text;
    }

    public void ovalDraw(Graphics2D g){
        int currentX = Math.min(startX, finishX);
        int currentY = Math.min(startY, finishY);
        int width = Math.abs(startX - finishX);
        int height = Math.abs(startY - finishY);
        g.setColor(color);
        g.drawOval(currentX, currentY, width, height);
    }

    public void setShape(SHAPE shape) {
        this.shape = shape;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getText() {
        return text;
    }

    public int[] getCoordination(){
        return new int[]{startX, startY, finishX, finishY};
    }

    public SHAPE getShape() {
        return shape;
    }

    public void setStartX(int startX) {
        this.startX = startX;
    }

    public void setStartY(int startY) {
        this.startY = startY;
    }

    public void setFinishX(int finishX){
        this.finishX = finishX;
    }

    public void setFinishY(int finishY){
        this.finishY = finishY;
    }
}
