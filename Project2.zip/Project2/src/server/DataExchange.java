import com.google.gson.Gson;
import javax.swing.*;
import java.io.*;
import java.net.SocketException;
import java.util.HashMap;

/**
 *@author Guangxing Si
 *@version 1.0
 */

public class DataExchange implements Runnable{
    private int counter;
    private Boolean listening = true;
    private DataInputStream input;
    private Gson gson = new Gson();
    private HashMap<String, DataOutputStream> outs;
    private ServerGUI serverGUI;
    private String userName;
    private HashMap<String, String> userListMap;

    public DataExchange(int counter, DataInputStream input, HashMap<String, DataOutputStream> outs,HashMap<String, String> userListMap, ServerGUI serverGUI ){
        this.input = input;
        this.counter = counter;
        this.outs = outs;
        this.userListMap = userListMap;
        this.userName = userListMap.get(String.valueOf(counter));
        sendUser(userListMap);
        this.serverGUI = serverGUI;
    }

    public void sendUser(HashMap<String, String> userListMap){
        String action = "USERLIST";
        for(String key : outs.keySet()){
            try{
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(gson.toJson(userListMap));
            }
            catch(IOException e){
                System.out.println(" Send shape in data exchange");
            }
        }
    }


    public void sendShape(String shapeJSONString){
        String action = "DRAW";
        int i = 0;
        for(String key : outs.keySet()){
            i++;
            try{
                if(counter == i){
                    continue;
                }
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(shapeJSONString);
            }
            catch(IOException e){
                System.out.println(" Send shape in dataexchange");
            }
        }
    }

    public void sendMsg(String msg){
        String action = "CHAT";
        int i = 0;
        for(String key : outs.keySet()){
            i++;
            try{
                if(counter == i){
                    continue;
                }
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(userName);
                outs.get(key).writeUTF(msg);

            }
            catch(IOException e){
                System.out.println("Send msg in data exchange");
            }
        }
    }
    public void sendStatus(String userNameID, String status){
        int i = 0;
        String action = "EDITING";
        for(String key : outs.keySet()){
            i++;
            try{
                if(counter == i)
                    continue;
                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(userNameID);
                outs.get(key).writeUTF(status);
            }
            catch(IOException e){
                System.out.println("Send msg in data exchange");
            }
        }
    }

    public void sendClear(){
        int i = 0;
        String action = "CLEAR";
        for(String key : outs.keySet()){
            i++;
            try{
                if(counter == i)
                    continue;
                outs.get(key).writeUTF(action);
            }
            catch(IOException e){
                System.out.println("Send msg in data exchange");
            }
        }
    }

    public void run() {

        String msg;
        while(listening){
            try {
                String clientAction = input.readUTF();
                switch(clientAction){
                    case "CHAT":
                        msg = input.readUTF();
                        sendMsg(msg);
                        serverGUI.setReceivedUserID(userName);
                        serverGUI.setchat(msg);
                        break;
                    case "DRAW":
                        String receivedShapeString = input.readUTF();
                        sendShape(receivedShapeString);
                        serverGUI.setDraw(receivedShapeString);
                        break;
                    case "CLEAR":
                        sendClear();
                        serverGUI.setClear();
                        break;
                    case "EDITING":
                        String status = input.readUTF();
                        sendStatus(String.valueOf(counter), status);
                        serverGUI.setStatus(String.valueOf(counter),status);
                        break;
                    default:
                        break;
                }
            } catch(SocketException e){
                System.out.println("User's socket terminated");
                JOptionPane.showMessageDialog(serverGUI, userName + "'s connection lost");
                userListMap.remove(String.valueOf(counter));
                sendUser(userListMap);
                serverGUI.setUserListMap(userListMap);
                serverGUI.setUserList();
                listening = false;
            }
            catch (IOException e) {
                System.out.println("IO exception");
            }
        }
    }
}