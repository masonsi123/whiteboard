import javax.swing.*;
import java.awt.*;
/**
 *@author Guangxing Si
 *@version 1.0
 */
class ComboBoxRender extends JLabel implements ListCellRenderer {
    boolean b = false;
    public ComboBoxRender() {

        setOpaque(true);
        setHorizontalAlignment(CENTER);
        setVerticalAlignment(CENTER);
    }
    public void setBackground(Color bg){
        if(!b){
            return;
        }

        super.setBackground(bg);
    }
    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        b = true;
        setText(" ");
        setBackground((Color)value);
        b = false;
        return this;
    }
}