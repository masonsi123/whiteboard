import com.google.gson.Gson;
import javax.net.ServerSocketFactory;
import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
/**
 * THIs is a distributed drawing board system
 * The Server class is defined to start a server to accept any incoming connection
 * requests and establish a connection with client. All client then will be distribute
 * to threads to handle their request
 *
 *@author Guangxing Si
 *@version 1.0
 */
public class Server {
    private HashMap<String, String> userListMap = new HashMap<>();
    private HashMap<String, Socket> acceptedSockets = new HashMap<>();
    private HashMap<String, DataOutputStream> outs = new HashMap<>();
    private ArrayList<DataInputStream> ins = new ArrayList<>();
    private ServerGUI serverGUI;
    private Gson gson = new Gson();
    private String managerName;

    public static void main(String[] args) {
        Server server = new Server();
        try{
            server.managerName = args[2];
        }catch(NullPointerException error){
            System.out.println("Please make sure enter a correct user name");
        }catch (ArrayIndexOutOfBoundsException error){
            System.out.println("Please enter correct number of arguments");
            System.exit(0);
        }
        server.setUpServer(args[0], args[1]);
    }

    public void setUpServer(String IP, String Port) {
        serverGUI = new ServerGUI(managerName);
        serverGUI.form();
        userListMap.put("0", managerName);
        System.out.println("manager is: " + userListMap.get(String.valueOf("0")));
        ServerSocket listeningSocket = null;
        // Define a client socket
        Socket clientSocket = null;

        // Port must be a integer between 0 to 65536
        int port = 0;
        try{
            port = Integer.parseInt(Port);
        }catch(NumberFormatException e){
            System.out.println("Port only can be a number");
            System.exit(0);
        }
        if(port > 65536 || port < 0){
            System.out.println("Port must be between 0 to 65536");
        }

        // Define a client number
        int counter = 0;

        // Create a server socket factory
        ServerSocketFactory factory = ServerSocketFactory.getDefault();

        // Define sever socket
        ServerSocket server = null;
        serverGUI.setUserList();
        try {
            // Create a localhost server with given port number
            server = factory.createServerSocket(port);
            System.out.println("Server is listening on port: " + port + " for a connection");

            // Create a always on listening server
            while(true) {
                // Obtain client socket and establish a connection
                clientSocket = server.accept();

                //acceptedClients.add(clientSocket);

                // Show client side information
                DataInputStream in = new DataInputStream(clientSocket.getInputStream());
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

                String userId = in.readUTF();
                int n = JOptionPane.showConfirmDialog(
                        serverGUI,
                        userId + " wants to join the drawing board",
                        "Inane warning",
                        JOptionPane.YES_NO_OPTION);
                if(n == 1){
                    out.writeUTF("NO");
                    clientSocket.close();
                }
                if(n == 0){
                    out.writeUTF("YES");
                    System.out.println("client -" + counter + "\tconnection accepted" + "\tremote hostname: " + clientSocket.getInetAddress().getHostName());
                    if(clientSocket != null){
                        counter++;
                        acceptedSockets.put(String.valueOf(counter), clientSocket);
                        userListMap.put(String.valueOf(counter), userId);
                        serverGUI.setClientSockets(acceptedSockets);
                        serverGUI.setUserListMap(userListMap);
                        serverGUI.setUserList();

                        System.out.println("first user added: " + userListMap.get(String.valueOf(counter)));

                        System.out.println(userListMap.toString());
                        ins.add(in);
                        outs.put(String.valueOf(counter), out);
                        serverGUI.setOuts(outs);
                        serverGUI.setUpDrawBoard(out);
                        DataExchange handleClient = new DataExchange(counter,in,outs, userListMap, serverGUI);
                        new Thread(handleClient).start();
                    }
                }
            }
        } catch(SocketException e){
            System.out.println("Socket exception encountered");

        }
        catch (IOException e) {
            System.out.println("I/O exception encountered");
        }
    }


}


