import com.google.gson.Gson;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
/**
 *@author Guangxing Si
 *@version 1.0
 */

public class ServerGUI extends JFrame{
    private DataInputStream in;
    private DataOutputStream out;
    private String clientId;
    private JTextArea msgIn = new JTextArea();
    private JTextArea msgOut = new JTextArea();
    private Canvas canvas;
    private JTextArea userListTextArea = new JTextArea();
    private Gson gson = new Gson();
    private HashMap<String, String> userListMap;
    private JLabel managerID = new JLabel();
    private String receivedUserID;
    private final Boolean IS_MANAGER = true;
    private String managerName;
    private HashMap<String, Socket> acceptedSockets;
    private HashMap<String, DataOutputStream> outs = new HashMap<>();
    private String editingUserID = "";

    public ServerGUI(String managerName){
        this.managerName = managerName;
        canvas = new Canvas();
        canvas.setIsManager(IS_MANAGER);
    }
    public void setDraw(String shapeJSONString){
        Painter receivedShape = gson.fromJson(shapeJSONString, Painter.class);
        canvas.addReceivedShape(receivedShape);
    }

    public void setOuts(HashMap<String, DataOutputStream> outs){
        this.outs = outs;
        canvas.setOuts(outs);
    }

    public void setClientSockets(HashMap<String, Socket> acceptedSockets){
        this.acceptedSockets = acceptedSockets;
    }

    public void setUserListMap(HashMap<String, String> userListMap){
        this.userListMap = userListMap;
    }

    public void setReceivedUserID(String receivedUserID){
        this.receivedUserID = receivedUserID;
    }

    public void setClear(){
        canvas.clear();
    }

    public void setchat(String msg){
        if(msgIn.getText().equals("Please chat here!")){
            msgIn.setText("");
        }
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");

        String date = dateFormatter.format(new Date(System.currentTimeMillis()));

        String receivedMessage = receivedUserID + " " + date + "\n" + "    " + msg + "\n";
        msgIn.append(receivedMessage);
        msgIn.setCaretPosition(msgIn.getText().length());

    }

    public void setStatus(String editingUserID,String status){
        if(status.equals("editing")){
            this.editingUserID = editingUserID;
        }else {
            this.editingUserID = "";
        }
        setUserList();

    }

    public ArrayList<Painter> readFile(File file){
        BufferedReader buffReader;
        StringBuffer stringBuffer = null;
        try{
            buffReader = new BufferedReader(new FileReader(file));
            stringBuffer = new StringBuffer();
            String str;
            while((str=buffReader.readLine())!=null){
                stringBuffer.append(str);
            }

        }catch (IOException e){
            System.out.println("save problem");
        }
        return gson.fromJson(stringBuffer.toString(), ArrayList.class);
    }

    public void writeFile(String path){
        FileOutputStream fos = null;
        try{
            fos = new FileOutputStream(new File(path));
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            BufferedWriter  bw = new BufferedWriter(osw);

            ArrayList<Painter> shapes = canvas.getShapes();
            for (Painter shape : shapes){
                bw.write(gson.toJson(shape) + "\n");
            }
            bw.close();
            osw.close();
            fos.close();
        }catch(FileNotFoundException e){
            System.out.println("Given filename is not fund please retry");
            System.exit(0);
        }catch(IOException e){
            System.out.println("There is an I/O exception in reading the file, please restart the server");
            System.exit(0);
        }
    }

    public void setUpDrawBoard(DataOutputStream out){
        ArrayList<Painter> shapes = canvas.getShapes();
        String action = "DRAW";
        try{
            for (Painter shape:shapes){
                out.writeUTF(action);
                out.writeUTF(gson.toJson(shape));
            }
        }catch(IOException e){
            System.out.println("IO error in sendMsg method");
        }
    }
    public void setUserList() {
        if(userListMap == null){
            managerID.setText(managerName);
            userListTextArea.append("No users join yet! \n");
            userListTextArea.append("You are logged in as Manager:\n" + "  *" + managerName + "\n\n");
        } else{
            managerID.setText(managerName);
            if(userListMap.isEmpty()){
                userListTextArea.setText("");
                userListTextArea.append("You are logged in as Manager:\n" + "  *" + managerName + "\n\n");
                userListTextArea.append("Other co-workers: " + "\n");
                userListTextArea.append("No more co-workers");
            }else{
                userListTextArea.setText("");
                userListTextArea.append("You are logged in as Manager:\n" + "  *" + managerName + "\n\n");
                userListTextArea.append("Other co-workers: " + "\n");
                for(String key: userListMap.keySet()){
                    String userID = userListMap.get(key);
                    if(!userID.equals(managerName))
                        if(key.equals(editingUserID))
                            userListTextArea.append("  -" + userID + "--Editing--" + "\n");
                        else
                            userListTextArea.append("  -" + userID + "\n");
                }
            }
        }
    }

    public void sendMsg(){
        try{
            for(String key : outs.keySet()){
                String action = "CHAT";

                outs.get(key).writeUTF(action);
                outs.get(key).writeUTF(managerName);
                outs.get(key).writeUTF(msgOut.getText());
            }

            if(msgIn.getText().equals("Please chat here!")){
                msgIn.setText("");
            }
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
            String date = dateFormatter.format(new Date(System.currentTimeMillis()));
            String ownMessage = "Me: " + date + "\n" + "    " + msgOut.getText() + "\n";
            msgIn.append(ownMessage);
        }catch(IOException e){
            System.out.println("IO error in sendMsg method");
        }
    }

    public void form(){
        JFrame jf = new JFrame("Welcome Manager " + managerName + "! Enjoy your drawing :D");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container container = jf.getContentPane();
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        container.setLayout(gbl);
        container.setBackground(new Color(57,118,150));
        gbc.fill = GridBagConstraints.BOTH;
        Border blackline = BorderFactory.createLineBorder(Color.black);
        Font font = new Font ("Serif", Font.BOLD, 15);

        TitledBorder titleBorderCanvas = BorderFactory.createTitledBorder(blackline, "Drawing Board", 1,2, font, Color.black);
        TitledBorder titleBorderUserList = BorderFactory.createTitledBorder(blackline, "User List", 1,2, font, Color.black);
        JPanel jl = new JPanel();
        jl.setPreferredSize(new Dimension(200, 500));
        JMenuBar jmb= new JMenuBar();
        JMenu jm = new JMenu("File");
        JMenuItem jmiNew = new JMenuItem("New");
        JMenuItem jmiOpen = new JMenuItem("Open");
        JMenuItem jmiSave = new JMenuItem("Save");
        JMenuItem jmiSaveAs = new JMenuItem("Save As");
        jmb.setBackground(Color.gray);
        jm.add(jmiNew);
        jm.add(jmiOpen);
        jm.add(jmiSave);
        jm.add(jmiSaveAs);
        jmb.add(jm);

        jmiNew.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                canvas.managerSendClear();
                canvas.clear();
            }
        });
        jmiOpen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                if (chooser.showOpenDialog(jmiOpen)==JFileChooser.APPROVE_OPTION) {//
                    File file = chooser.getSelectedFile();
                    canvas.clear();
                    canvas.managerSendClear();
                    try{
                        FileReader fr = new FileReader(file);
                        BufferedReader br = new BufferedReader(fr);
                        String line = "";
                        while ((line = br.readLine()) != null) {
                            setDraw(line);
                            canvas.managerSendShape(line);
                        }
                    }catch(IOException error){
                        System.out.println("Exception while reading the file");
                    }
                };
            }
        });

        jmiSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    File drawingBoard = new File("DrawingBoard");
                    if(drawingBoard.exists()){
                        drawingBoard.delete();
                    }else{
                        drawingBoard.createNewFile();
                    }
                    writeFile("DrawingBoard");
                }catch(IOException error){
                    System.out.println("Exception in save function");
                }
            }
        });

        jmiSaveAs.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                JFileChooser chooser = new JFileChooser();
                if (chooser.showSaveDialog(jmiSaveAs)==JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    writeFile(file.getPath());
                }
            }
        });

        jf.setJMenuBar(jmb);
        JPanel userListPan = new JPanel();

        userListPan.setPreferredSize(new Dimension(200, 450));
        userListTextArea.setWrapStyleWord(true);
        userListTextArea.setLineWrap(true);
        userListTextArea.setEditable(false);

        JScrollPane userListScrollPane = new JScrollPane(userListTextArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        userListScrollPane.setPreferredSize(new Dimension(190, 400));
        userListPan.setBackground(new Color(196,196,196));
        userListPan.setBorder(titleBorderUserList);
        userListPan.add(new JLabel("Manager: "), gbc);
        userListPan.add(managerID, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        userListPan.add(userListScrollPane,gbc);
        jl.add(userListPan, gbc);

        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(196,196,196));
        controlPanel.setPreferredSize(new Dimension(190, 450));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;

        jl.add(controlPanel, gbc);
        JButton buttonClose = new JButton("Close");
        JButton buttonKick = new JButton("Kick");
        controlPanel.add(buttonClose);
        controlPanel.add(buttonKick);

        gbc.insets = new Insets(10,10,10,10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        jl.setBackground(new Color(196,196,196));
        container.add(jl, gbc);

        JPanel jr = new JPanel();
        jr.setPreferredSize(new Dimension(980, 500));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        jr.setBackground(new Color(196,196,196));
        container.add(jr, gbc);
        jr.setLayout(gbl);

        canvas.setBorder(titleBorderCanvas);
        gbc.insets =  new Insets(10,0,5,0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        jr.add(canvas, gbc);

        JPanel toolPan = new JPanel();
        toolPan.setPreferredSize(new Dimension(300, 30));
        gbc.insets =  new Insets(0,0,5,0);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        toolPan.setBackground(new Color(196,196,196));
        jr.add(toolPan, gbc);

        JPanel chatPan = new JPanel();
        chatPan.setPreferredSize(new Dimension(980, 220));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        chatPan.setBackground(new Color(196,196,196));
        jr.add(chatPan, gbc);

        JPanel receivePan = new JPanel();
        receivePan.setPreferredSize(new Dimension(430, 200));
        JLabel labelReceive = new JLabel("Chat Box");

        msgIn.setName("msgIn");
        msgIn.setWrapStyleWord(true);
        msgIn.setLineWrap(true);
        msgIn.setText("Please chat here!");
        msgIn.setEditable(false);
        JScrollPane chatMsgIn = new JScrollPane(msgIn, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        chatMsgIn.setPreferredSize(new Dimension(410, 170));

        receivePan.add(chatMsgIn, gbc);
        receivePan.add(labelReceive);

        JPanel sendPan = new JPanel();
        sendPan.setPreferredSize(new Dimension(430, 200));

        msgOut.setName("msgOut");
        msgOut.setWrapStyleWord(true);
        msgOut.setLineWrap(true);
        msgOut.setText("Type message here...");
        msgOut.setEditable(true);
        JScrollPane chatMsgOut = new JScrollPane(msgOut, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        chatMsgOut.setPreferredSize(new Dimension(410, 150));

        JButton buttonSend = new JButton("Send");
        JButton buttonCancel = new JButton("Cancel");
        gbc.weightx = 1;
        gbc.weighty = 1;
        chatPan.add(receivePan,gbc);
        chatPan.add(sendPan,gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;

        sendPan.add(chatMsgOut,gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        sendPan.add(buttonSend, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        sendPan.add(buttonCancel,gbc);

        JButton buttonCircle = new JButton("Circle");
        JButton buttonLine = new JButton("Line");
        JButton buttonOval = new JButton("Oval");
        JButton buttonRectangle = new JButton("Rectangle");
        JButton buttonClear = new JButton("Clear");
        JButton buttonText = new JButton("Text");
        buttonText.setBorder(BorderFactory.createRaisedBevelBorder());

        GridLayout gl = new GridLayout();
        gl.setHgap(10);
        toolPan.setLayout(gl);

        toolPan.add(buttonText);
        toolPan.add(buttonCircle);
        toolPan.add(buttonLine);
        toolPan.add(buttonOval);
        toolPan.add(buttonRectangle);
        toolPan.add(buttonClear);


        Color[] colorList = new Color[]{Color.black,Color.white,Color.red,new Color(0,255,0),Color.blue,Color.yellow,Color.cyan,Color.magenta,new Color(192,192,192),Color.gray,new Color(128,0,0),new Color(128,128,0),Color.green,new Color(128,0,128),new Color(60, 0,128),new Color(0,0,128)};
        JComboBox colorDropdownList = new JComboBox(colorList);
        ComboBoxRender renderer = new ComboBoxRender();
        colorDropdownList.setPreferredSize(new Dimension(80,25));
        colorDropdownList.setRenderer(renderer);
        JLabel colorLable = new JLabel("          Color Selector");
        toolPan.add(colorLable);
        toolPan.add(colorDropdownList);



        ActionListener actionListener = e -> {
            if(e.getSource() == buttonClear){
                int n = JOptionPane.showConfirmDialog(
                        jf,
                        "Are you sure you want to clean the board",
                        "An Inane Question",
                        JOptionPane.YES_NO_OPTION);
                if(n == 0){
                    canvas.clear();
                    canvas.sendClear();
                }
            }else if(e.getSource() == buttonLine){
                canvas.setShape(SHAPE.LINE);
            }else if(e.getSource() == buttonKick){


                if(userListMap == null){
                    JOptionPane.showMessageDialog(jf,
                            "There is no one to kick out!");
                }else {
                    ArrayList <String> options = new ArrayList<>();
                    for (String key : userListMap.keySet()){
                        if(userListMap.get(key).equals(managerName))
                            continue;
                        options.add(userListMap.get(key));
                    }
                    Object[] possibilities = options.toArray();
                    String s = (String)JOptionPane.showInputDialog(
                            jf,
                            "Who do you want to kick out?",
                            "Kick Out",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            possibilities,
                            "Please select!");

                    for (String key : userListMap.keySet()){
                        if(userListMap.get(key).equals(s)){
                            try{
                                acceptedSockets.get(key).close();
                                outs.remove(key);

                            }catch (IOException error){
                                System.out.println("Manager kick people error");
                            }
                        }
                    }
                }
            }else if(e.getSource() == buttonClose){
                int n = JOptionPane.showConfirmDialog(
                        jf,
                        "You are about to shutdown the drawing board!",
                        "An Inane Question",
                        JOptionPane.YES_NO_OPTION);
                if(n == 0){
                    for(String key : outs.keySet()){
                        try{
                            outs.get(key).close();
                        }catch(IOException error){
                            System.out.println("Error occurs during manager shoutdown the server");
                        }
                    }
                    System.exit(0);
                }
            }else if(e.getSource() == buttonRectangle){
                canvas.setShape(SHAPE.RECTANGLE);
            }else if(e.getSource() == buttonOval){
                canvas.setShape(SHAPE.OVAL);
            }else if(e.getSource() == buttonCircle){
                canvas.setShape(SHAPE.CIRCLE);
            }else if(e.getSource() == buttonText){
                canvas.setShape(SHAPE.TEXT);
            }else if(e.getSource() == buttonSend){
                sendMsg();
                msgIn.setCaretPosition(msgIn.getText().length());
            }else if(e.getSource() == buttonCancel){
                msgOut.setText("");
            }else if(e.getSource() == colorDropdownList){
                int colorIndex = colorDropdownList.getSelectedIndex();
                Color selectedColor = colorList[colorIndex];
                canvas.setBasicColor(selectedColor);
            }
        };


        buttonClose.addActionListener(actionListener);
        buttonKick.addActionListener(actionListener);
        buttonCircle.addActionListener(actionListener);
        buttonLine.addActionListener(actionListener);
        buttonOval.addActionListener(actionListener);
        buttonRectangle.addActionListener(actionListener);
        buttonClear.addActionListener(actionListener);
        buttonText.addActionListener(actionListener);
        colorDropdownList.addActionListener(actionListener);
        buttonCancel.addActionListener(actionListener);
        buttonSend.addActionListener(actionListener);

        msgOut.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                super.focusGained(e);
                if(msgOut.getText().endsWith("Type message here...")){
                    msgOut.setText("");
                }

            }
        });

        jf.setSize(1300,800);
        jf.setVisible(true);
    }
}
