The first user creates a whiteboard and becomes the whiteboard’s
manager
 java CreateWhiteBoard <serverIPAddress> <serverPort> username
 Other users can ask to join the whiteboard application any time by
inputting server’s IP address and port number
 java JoinWhiteBoard <serverIPAddress> <serverPort> username
 A notification will be delivered to the manager if any peer wants to
join. The peer can join in only after the manager approves
 A dialog showing “someone wants to share your whiteboard”.